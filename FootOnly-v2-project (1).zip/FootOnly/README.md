# FootOnly 2.0

1. Download NudeNet's `320n.onnx` and put it in `app/src/main/assets/320n.onnx` (see the txt file there).
2. Open this folder in Android Studio (Ladybug or newer), let Gradle sync.
3. Build > Build APK(s). Debug APK: app/build/outputs/apk/debug/.
4. Install on an Android 14+ phone, open the app, tap Enable, turn on FootOnly under Accessibility.
   (Sideloaded on Android 13+? App info > ⋮ > "Allow restricted settings" first.)
5. Add the "FootOnly" tile to Quick Settings for one-tap pause/resume.

## Build the APK on GitHub (no Android Studio)
See the step-by-step in the chat: upload this folder's contents to a new GitHub repo, add the workflow file
.github/workflows/build.yml, then download the "FootOnly-debug-apk" artifact from the Actions tab.
The workflow downloads 320n.onnx automatically if it isn't already in app/src/main/assets/.
