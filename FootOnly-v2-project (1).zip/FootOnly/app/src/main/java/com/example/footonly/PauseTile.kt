package com.example.footonly

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** One-tap pause/resume from the Quick Settings panel. */
class PauseTile : TileService() {
    override fun onStartListening() = refresh()

    override fun onClick() {
        val c = FilterConfig.load(this)
        c.copy(paused = !c.paused).save(this)
        refresh()
    }

    private fun refresh() {
        val paused = FilterConfig.load(this).paused
        qsTile?.apply {
            state = if (paused) Tile.STATE_INACTIVE else Tile.STATE_ACTIVE
            label = "FootOnly"
            subtitle = if (paused) "Paused" else "Filtering"
            updateTile()
        }
    }
}
