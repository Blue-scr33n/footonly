package com.example.footonly

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.ImageView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import kotlin.coroutines.resume

/**
 * Screenshots the foreground app window (without our own overlay, via takeScreenshotOfWindow),
 * runs the NudeNet detector, and draws censor patches (or a "show only" frame) on top.
 */
class FootOnlyService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val bgExecutor = Executors.newSingleThreadExecutor()
    private var detector: NudeDetector? = null
    private lateinit var wm: WindowManager
    private lateinit var overlay: ImageView
    private var lastBounds = Rect()

    private val modelPresent by lazy { assets.list("")?.contains(NudeDetector.MODEL) == true }

    // Never filtered, so you can always reach Settings (and your launcher) to turn this off.
    private val allow by lazy {
        val home = packageManager
            .resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            ?.activityInfo?.packageName
        setOfNotNull(
            packageName, home, "com.android.settings", "com.android.systemui",
            "com.google.android.permissioncontroller"
        )
    }

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            visibility = View.GONE
        }
        wm.addView(overlay, layoutParams(Rect(0, 0, 1, 1)))
        Stats.startSession(this)
        scope.launch { loop() }
    }

    private fun layoutParams(b: Rect) = WindowManager.LayoutParams(
        b.width().coerceAtLeast(1), b.height().coerceAtLeast(1),
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or // taps pass through to the app
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = b.left
        y = b.top
    }

    private suspend fun loop() {
        while (currentCoroutineContext().isActive) {
            val start = SystemClock.elapsedRealtime()
            val cfg = FilterConfig.load(this)
            runCatching { tick(cfg) }.onFailure {
                // "Only show selected" fails closed; normal censoring just keeps the last overlay.
                if (cfg.mode == Mode.ONLY_SHOW_SELECTED) blackout(lastBounds)
            }
            // The system rate-limits screenshots, so roughly 2-3 fps is the ceiling.
            delay((cfg.refreshMs - (SystemClock.elapsedRealtime() - start)).coerceAtLeast(50))
        }
    }

    private suspend fun tick(cfg: FilterConfig) {
        if (cfg.paused || !modelPresent) return hide()

        val win = withContext(Dispatchers.Main) {
            windows.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }?.let {
                Triple(it.id, it.root?.packageName?.toString().orEmpty(), Rect().also { r -> it.getBoundsInScreen(r) })
            }
        }
        if (win == null || win.second in allow || win.second in cfg.ignoredApps) return hide()

        val (id, _, bounds) = win
        val shot = screenshot(id)
        if (shot == null) { // e.g. secure window
            if (cfg.mode == Mode.ONLY_SHOW_SELECTED) blackout(bounds) else hide()
            return
        }

        val det = detector ?: NudeDetector(this).also { detector = it }
        val res = FilterRenderer.render(shot, det.detect(shot, cfg.threshold, cfg.deepScan), cfg)
        Stats.record(this, cfg.refreshMs.toLong(), res.blocked > 0)

        if (cfg.mode == Mode.CENSOR_SELECTED && res.blocked == 0) return hide()
        withContext(Dispatchers.Main) { show(res.bitmap, bounds, cfg.mode) }
    }

    private suspend fun screenshot(windowId: Int): Bitmap? = suspendCancellableCoroutine { cont ->
        takeScreenshotOfWindow(windowId, bgExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                val sw = hw?.copy(Bitmap.Config.ARGB_8888, false)
                r.hardwareBuffer.close()
                cont.resume(sw)
            }

            override fun onFailure(errorCode: Int) = cont.resume(null)
        })
    }

    private fun place(bounds: Rect) {
        if (bounds != lastBounds) {
            lastBounds = Rect(bounds)
            wm.updateViewLayout(overlay, layoutParams(bounds))
        }
    }

    private fun show(bmp: Bitmap, bounds: Rect, mode: Mode) {
        place(bounds)
        overlay.setBackgroundColor(if (mode == Mode.ONLY_SHOW_SELECTED) Color.BLACK else Color.TRANSPARENT)
        overlay.setImageBitmap(bmp)
        overlay.visibility = View.VISIBLE
    }

    private suspend fun blackout(bounds: Rect) = withContext(Dispatchers.Main) {
        place(bounds)
        overlay.setBackgroundColor(Color.BLACK)
        overlay.setImageDrawable(null)
        overlay.visibility = View.VISIBLE
    }

    private suspend fun hide() = withContext(Dispatchers.Main) { overlay.visibility = View.GONE }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        scope.cancel()
        bgExecutor.shutdown()
        runCatching { wm.removeView(overlay) }
        detector?.close()
        super.onDestroy()
    }
}
