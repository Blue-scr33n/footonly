package com.example.footonly

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                App(resumeTick)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++ // re-check service state when returning from Settings
    }
}

fun isServiceEnabled(ctx: Context): Boolean {
    val am = ctx.getSystemService(AccessibilityManager::class.java)
    return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        .any { it.resolveInfo.serviceInfo.packageName == ctx.packageName }
}

fun modelPresent(ctx: Context) = ctx.assets.list("")?.contains(NudeDetector.MODEL) == true

@Composable
fun App(resumeTick: Int) {
    val ctx = LocalContext.current
    var cfg by remember { mutableStateOf(FilterConfig.load(ctx)) }
    val change: (FilterConfig) -> Unit = { cfg = it; it.save(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    val enabled = remember(resumeTick) { isServiceEnabled(ctx) }

    // The Quick Settings tile can change "paused" while we're open.
    LaunchedEffect(resumeTick) { cfg = FilterConfig.load(ctx) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf("🏠" to "Home", "🧩" to "Parts", "🎚️" to "Tune", "📱" to "Apps", "📊" to "Stats")
                    .forEachIndexed { i, (emoji, label) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(emoji) },
                            label = { Text(label) }
                        )
                    }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeTab(enabled, cfg, change)
                1 -> PartsTab(cfg, change)
                2 -> TuneTab(cfg, change)
                3 -> AppsTab(cfg, change)
                else -> StatsTab(enabled)
            }
        }
    }
}

// ---------- shared bits ----------

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onCheck: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(sub, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = checked, onCheckedChange = onCheck)
    }
}

@Composable
fun LabeledSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>,
    display: String, onChange: (Float) -> Unit
) {
    Column {
        Text("$label: $display", style = MaterialTheme.typography.titleSmall)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun <T> Segmented(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        options.forEachIndexed { i, o ->
            SegmentedButton(
                selected = o == selected,
                onClick = { onSelect(o) },
                shape = SegmentedButtonDefaults.itemShape(i, options.size)
            ) { Text(label(o)) }
        }
    }
}

// ---------- Home ----------

private data class Preset(val name: String, val refreshMs: Int, val deep: Boolean)

private val presets = listOf(
    Preset("Low", 1000, false), Preset("Medium", 600, false),
    Preset("High", 400, false), Preset("Ultra", 300, true)
)

@Composable
fun HomeTab(enabled: Boolean, cfg: FilterConfig, onChange: (FilterConfig) -> Unit) {
    val ctx = LocalContext.current
    val hasModel = remember { modelPresent(ctx) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("FootOnly", style = MaterialTheme.typography.headlineMedium)

        if (!hasModel) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Detection model missing", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Put NudeNet's 320n.onnx in app/src/main/assets/ and rebuild. " +
                            "Until then the filter does nothing."
                    )
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (enabled) "● Filter service is ON" else "○ Filter service is OFF",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    if (enabled) {
                        if (cfg.mode == Mode.ONLY_SHOW_SELECTED) "Everything is covered except the parts you chose to show."
                        else "Selected parts are covered wherever they appear."
                    } else "Turn on FootOnly under Accessibility to start filtering."
                )
                Button(onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }) { Text(if (enabled) "Manage in Settings" else "Enable") }
            }
        }

        SwitchRow("Pause filter", "Also available as a Quick Settings tile", cfg.paused) {
            onChange(cfg.copy(paused = it))
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Performance", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { p ->
                    FilterChip(
                        selected = cfg.refreshMs == p.refreshMs && cfg.deepScan == p.deep,
                        onClick = { onChange(cfg.copy(refreshMs = p.refreshMs, deepScan = p.deep)) },
                        label = { Text(p.name) }
                    )
                }
            }
            Text(
                "Higher = faster refresh (and deep scan on Ultra) but more battery.",
                style = MaterialTheme.typography.bodySmall
            )
        }

        TestCard(cfg)

        Text(
            "Safety: Settings, system UI and your home screen are never filtered, so you can always get back here to turn this off. " +
                "Sideloaded on Android 13+? App info > ⋮ > Allow restricted settings first.",
            style = MaterialTheme.typography.bodySmall
        )
        Text(
            "Privacy: screenshots are processed on-device only. Nothing is saved or sent anywhere.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun TestCard(cfg: FilterConfig) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var detector by remember { mutableStateOf<NudeDetector?>(null) }
    var result by remember { mutableStateOf<Bitmap?>(null) }
    var status by remember { mutableStateOf("Preview your current settings on a photo.") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        status = "Processing…"
        result = null
        scope.launch {
            val out = withContext(Dispatchers.Default) {
                runCatching {
                    val det = detector ?: NudeDetector(ctx).also { detector = it }
                    val bmp = loadBitmap(ctx, uri)
                    val dets = det.detect(bmp, cfg.threshold, cfg.deepScan)
                    val res = FilterRenderer.render(bmp, dets, cfg)
                    FilterRenderer.preview(bmp, res) to dets.size
                }.getOrNull()
            }
            result = out?.first
            status = when {
                out == null -> "Couldn't process that (is 320n.onnx in assets?)."
                else -> "${out.second} detection(s) found."
            }
        }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Test on a photo", style = MaterialTheme.typography.titleMedium)
            Text(status, style = MaterialTheme.typography.bodySmall)
            Button(onClick = {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }) { Text("Choose photo") }
            result?.let { bmp ->
                Image(
                    bitmap = bmp.asImageBitmap(), contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)
                )
                OutlinedButton(onClick = {
                    scope.launch(Dispatchers.IO) { saveBitmap(ctx, bmp) }
                    status = "Saved to Pictures/FootOnly"
                }) { Text("Save filtered copy") }
            }
        }
    }
}

// ---------- Parts (mode, profiles, per-part rules) ----------

@Composable
fun PartsTab(cfg: FilterConfig, onChange: (FilterConfig) -> Unit) {
    val ctx = LocalContext.current
    var custom by remember { mutableStateOf(Profiles.loadCustom(ctx)) }
    var showSave by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }

    fun apply(p: Profile) = onChange(cfg.copy(mode = p.mode, rules = p.rules))
    fun matches(p: Profile) = p.mode == cfg.mode && p.rules == cfg.rules.filterValues { it != Rule.OFF }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Parts", style = MaterialTheme.typography.headlineMedium)

        Text("Mode", style = MaterialTheme.typography.titleSmall)
        Segmented(
            Mode.values().toList(), cfg.mode,
            { if (it == Mode.CENSOR_SELECTED) "Cover selected" else "Only show selected" }
        ) { onChange(cfg.copy(mode = it)) }
        Text(
            if (cfg.mode == Mode.CENSOR_SELECTED) "Parts set to Cover are hidden; everything else shows normally."
            else "Everything is covered except parts set to Show. Parts set to Cover stay hidden even inside shown areas.",
            style = MaterialTheme.typography.bodySmall
        )

        Text("Profiles", style = MaterialTheme.typography.titleSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Profiles.builtins.forEach { p ->
                FilterChip(selected = matches(p), onClick = { apply(p) }, label = { Text(p.name) })
            }
        }
        custom.forEach { p ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("★ ${p.name}", Modifier.weight(1f))
                TextButton(onClick = { apply(p) }) { Text("Apply") }
                TextButton(onClick = {
                    custom = custom - p
                    Profiles.saveCustom(ctx, custom)
                }) { Text("Delete") }
            }
        }
        OutlinedButton(onClick = { showSave = true }) { Text("Save current as profile") }

        NudeClasses.groups.forEach { (group, ids) ->
            Text(group, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
            ids.forEach { id ->
                val shown = if (cfg.mode == Mode.ONLY_SHOW_SELECTED) listOf(Rule.OFF, Rule.CENSOR, Rule.ALLOW)
                else listOf(Rule.OFF, Rule.CENSOR)
                var cur = cfg.rules[id] ?: Rule.OFF
                if (cur !in shown) cur = Rule.OFF
                Column {
                    Text(NudeClasses.names[id], style = MaterialTheme.typography.bodyMedium)
                    Segmented(
                        shown, cur,
                        { when (it) { Rule.OFF -> "Off"; Rule.CENSOR -> "Cover"; Rule.ALLOW -> "Show" } }
                    ) { r ->
                        onChange(cfg.copy(rules = if (r == Rule.OFF) cfg.rules - id else cfg.rules + (id to r)))
                    }
                }
            }
        }
    }

    if (showSave) {
        AlertDialog(
            onDismissRequest = { showSave = false },
            title = { Text("Save profile") },
            text = {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Name") })
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) {
                        custom = custom.filter { it.name != name.trim() } +
                            Profile(name.trim(), cfg.mode, cfg.rules.filterValues { it != Rule.OFF })
                        Profiles.saveCustom(ctx, custom)
                        name = ""
                        showSave = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showSave = false }) { Text("Cancel") } }
        )
    }
}

// ---------- Tune ----------

@Composable
fun TuneTab(cfg: FilterConfig, onChange: (FilterConfig) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Tune", style = MaterialTheme.typography.headlineMedium)

        Text("Censor style", style = MaterialTheme.typography.titleSmall)
        Segmented(
            Style.values().toList(), cfg.style,
            { when (it) { Style.BOX -> "Black box"; Style.PIXELATE -> "Pixelate"; Style.BLUR -> "Blur" } }
        ) { onChange(cfg.copy(style = it)) }

        LabeledSlider("Censor strength", cfg.intensity.toFloat(), 8f..80f, "${cfg.intensity}px blocks") {
            onChange(cfg.copy(intensity = it.toInt()))
        }
        LabeledSlider("Box padding", cfg.margin, 0f..0.5f, "${(cfg.margin * 100).toInt()}%") {
            onChange(cfg.copy(margin = it))
        }
        LabeledSlider(
            "Sensitivity", 0.7f - cfg.threshold + 0.15f, 0.15f..0.7f,
            "${((0.7f - cfg.threshold + 0.15f) * 100).toInt()}% (higher catches more, more false alarms)"
        ) { onChange(cfg.copy(threshold = 0.7f - it + 0.15f)) }
        LabeledSlider(
            "Refresh interval", cfg.refreshMs.toFloat(), 300f..1500f,
            "${cfg.refreshMs} ms (faster = more battery)"
        ) { onChange(cfg.copy(refreshMs = it.toInt())) }

        SwitchRow(
            "Deep scan", "Also scans overlapping halves of the screen to catch smaller things (slower)",
            cfg.deepScan
        ) { onChange(cfg.copy(deepScan = it)) }

        OutlinedButton(onClick = {
            onChange(FilterConfig(rules = cfg.rules, mode = cfg.mode, ignoredApps = cfg.ignoredApps))
        }) { Text("Reset sliders") }
    }
}

// ---------- Apps ----------

@Composable
fun AppsTab(cfg: FilterConfig, onChange: (FilterConfig) -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(16.dp)) {
            Text("Never filter these apps", style = MaterialTheme.typography.headlineSmall)
            Text("Checked apps are shown normally.", style = MaterialTheme.typography.bodySmall)
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(apps, key = { it.second }) { (label, pkg) ->
                val toggle = {
                    onChange(
                        cfg.copy(
                            ignoredApps = if (pkg in cfg.ignoredApps) cfg.ignoredApps - pkg else cfg.ignoredApps + pkg
                        )
                    )
                }
                Row(
                    Modifier.fillMaxWidth().clickable { toggle() }.padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = pkg in cfg.ignoredApps, onCheckedChange = { toggle() })
                    Text(label)
                }
            }
        }
    }
}

// ---------- Stats + achievements ----------

private fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%dh %02dm".format(s / 3600, (s % 3600) / 60)
}

@Composable
fun StatsTab(enabled: Boolean) {
    val ctx = LocalContext.current
    var snap by remember { mutableStateOf(Stats.snapshot(ctx)) }
    var now by remember { mutableStateOf(SystemClock.elapsedRealtime()) }

    LaunchedEffect(Unit) {
        while (true) {
            snap = Stats.snapshot(ctx)
            now = SystemClock.elapsedRealtime()
            delay(1000)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Stats", style = MaterialTheme.typography.headlineMedium)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (enabled && Stats.sessionStart > 0) {
                    Text("This session: ${fmt(now - Stats.sessionStart)} · ${Stats.sessionBlocked} blocked")
                }
                Text("All time: ${fmt(snap.activeMs)} filtering")
                Text("Moments blocked: ${snap.blocked}")
                Text("Sessions: ${snap.sessions}")
            }
        }

        Text("Achievements", style = MaterialTheme.typography.titleMedium)
        Stats.achievements.forEach { a ->
            val done = a.unlocked(snap)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (done) "✅  " else "🔒  ")
                Column {
                    Text(a.title, style = MaterialTheme.typography.titleSmall)
                    Text(a.desc, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        OutlinedButton(onClick = { Stats.reset(ctx); snap = Stats.snapshot(ctx) }) { Text("Reset stats") }
    }
}

// ---------- image helpers ----------

fun loadBitmap(ctx: Context, uri: Uri): Bitmap {
    val source = ImageDecoder.createSource(ctx.contentResolver, uri)
    return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val scale = 2048f / maxOf(info.size.width, info.size.height)
        if (scale < 1f) {
            decoder.setTargetSize((info.size.width * scale).toInt(), (info.size.height * scale).toInt())
        }
    }
}

/** Re-encoding also strips EXIF/GPS metadata. */
fun saveBitmap(ctx: Context, bmp: Bitmap) {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "footonly_${System.currentTimeMillis()}.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FootOnly")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return
    ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
}
