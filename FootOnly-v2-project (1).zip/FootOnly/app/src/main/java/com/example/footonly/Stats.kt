package com.example.footonly

import android.content.Context
import android.os.SystemClock

data class StatsSnapshot(val sessions: Int, val activeMs: Long, val blocked: Long)
data class Achievement(val title: String, val desc: String, val unlocked: (StatsSnapshot) -> Boolean)

object Stats {
    private const val FILE = "footonly_stats"
    @Volatile var sessionStart = 0L
    @Volatile var sessionBlocked = 0

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun startSession(c: Context) {
        sessionStart = SystemClock.elapsedRealtime()
        sessionBlocked = 0
        sp(c).edit().putInt("sessions", sp(c).getInt("sessions", 0) + 1).apply()
    }

    /** Called once per filter refresh. "Blocked" counts refreshes where something was covered. */
    fun record(c: Context, activeMs: Long, blocked: Boolean) {
        val p = sp(c)
        p.edit()
            .putLong("activeMs", p.getLong("activeMs", 0) + activeMs)
            .putLong("blocked", p.getLong("blocked", 0) + if (blocked) 1 else 0)
            .apply()
        if (blocked) sessionBlocked++
    }

    fun snapshot(c: Context): StatsSnapshot {
        val p = sp(c)
        return StatsSnapshot(p.getInt("sessions", 0), p.getLong("activeMs", 0), p.getLong("blocked", 0))
    }

    fun reset(c: Context) = sp(c).edit().clear().apply()

    private const val HOUR = 3_600_000L
    val achievements = listOf(
        Achievement("First block", "Something got covered for the first time") { it.blocked >= 1 },
        Achievement("100 moments blocked", "Covered 100 times") { it.blocked >= 100 },
        Achievement("1,000 moments blocked", "Covered 1,000 times") { it.blocked >= 1_000 },
        Achievement("One hour in", "1 hour of filtering") { it.activeMs >= HOUR },
        Achievement("Ten hours in", "10 hours of filtering") { it.activeMs >= 10 * HOUR },
        Achievement("Hundred hours in", "100 hours of filtering") { it.activeMs >= 100 * HOUR }
    )
}
