package com.example.footonly

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import kotlin.math.max
import kotlin.math.min

/**
 * CENSOR_SELECTED: returns a transparent bitmap holding only the censor patches (live app shows through).
 * ONLY_SHOW_SELECTED: returns an opaque frame, fully covered except "Show" parts; "Cover" parts stay covered.
 */
object FilterRenderer {

    class Result(val bitmap: Bitmap, val blocked: Int)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val black = Paint().apply { color = Color.BLACK }

    fun render(src: Bitmap, dets: List<NudeDetector.Det>, cfg: FilterConfig): Result {
        val w = src.width
        val h = src.height
        val censor = dets.filter { cfg.rules[it.cls] == Rule.CENSOR }.map { pad(it.box, cfg.margin, w, h) }

        if (cfg.mode == Mode.ONLY_SHOW_SELECTED) {
            val allow = dets.filter { cfg.rules[it.cls] == Rule.ALLOW }.map { pad(it.box, cfg.margin, w, h) }
            val out = base(src, cfg)
            val canvas = Canvas(out)
            for (r in allow) {
                canvas.save()
                canvas.clipPath(Path().apply { addRoundRect(r, 24f, 24f, Path.Direction.CW) })
                canvas.drawBitmap(src, toRect(r), r, paint)
                canvas.restore()
            }
            for (r in censor) patch(canvas, src, r, cfg) // cover faces/nudity even inside shown areas
            return Result(out, censor.size)
        }

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        for (r in censor) patch(canvas, src, r, cfg)
        return Result(out, censor.size)
    }

    /** For the in-app preview: draws the censor result over the original screenshot. */
    fun preview(src: Bitmap, res: Result): Bitmap {
        val copy = src.copy(Bitmap.Config.ARGB_8888, true)
        Canvas(copy).drawBitmap(res.bitmap, 0f, 0f, null)
        return copy
    }

    private fun pad(b: RectF, margin: Float, w: Int, h: Int): RectF {
        val m = max(b.width(), b.height()) * margin
        return RectF(
            max(0f, b.left - m), max(0f, b.top - m),
            min(w.toFloat(), b.right + m), min(h.toFloat(), b.bottom + m)
        )
    }

    private fun toRect(r: RectF) = Rect(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt())

    private fun base(src: Bitmap, cfg: FilterConfig): Bitmap = when (cfg.style) {
        Style.BOX -> Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888).also { it.eraseColor(Color.BLACK) }
        Style.PIXELATE -> scaleEffect(src, cfg.intensity, smooth = false)
        Style.BLUR -> scaleEffect(src, cfg.intensity, smooth = true)
    }

    /** Shrink then enlarge: blocky when [smooth] is false, soft blur when true. Irreversible either way. */
    private fun scaleEffect(src: Bitmap, block: Int, smooth: Boolean): Bitmap {
        val w = src.width
        val h = src.height
        val tiny = Bitmap.createScaledBitmap(src, (w / block).coerceAtLeast(1), (h / block).coerceAtLeast(1), true)
        return Bitmap.createScaledBitmap(tiny, w, h, smooth).copy(Bitmap.Config.ARGB_8888, true)
    }

    private fun patch(canvas: Canvas, src: Bitmap, r: RectF, cfg: FilterConfig) {
        val ir = toRect(r)
        ir.intersect(0, 0, src.width, src.height)
        if (ir.width() < 2 || ir.height() < 2) return
        when (cfg.style) {
            Style.BOX -> canvas.drawRect(ir, black)
            else -> {
                val crop = Bitmap.createBitmap(src, ir.left, ir.top, ir.width(), ir.height())
                val fx = scaleEffect(crop, cfg.intensity, smooth = cfg.style == Style.BLUR)
                canvas.drawBitmap(fx, ir.left.toFloat(), ir.top.toFloat(), null)
                crop.recycle()
                fx.recycle()
            }
        }
    }
}
