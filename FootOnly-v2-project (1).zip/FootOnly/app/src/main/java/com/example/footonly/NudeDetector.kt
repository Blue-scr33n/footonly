package com.example.footonly

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Runs NudeNet's 320n YOLOv8 model (assets/320n.onnx) with ONNX Runtime.
 * Output is [1, 22, 2100]: 4 box values (cx, cy, w, h) + 18 class scores per anchor.
 */
class NudeDetector(ctx: Context) {

    data class Det(val cls: Int, val score: Float, val box: RectF)

    companion object {
        const val MODEL = "320n.onnx"
        private const val SIZE = 320
        private const val NUM_CLASSES = 18
    }

    private val env = OrtEnvironment.getEnvironment()
    private val session: OrtSession = env.createSession(
        ctx.assets.open(MODEL).use { it.readBytes() },
        OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) }
    )
    private val inputName = session.inputNames.first()
    private val resizePaint = Paint(Paint.FILTER_BITMAP_FLAG)

    /** Detections in the pixel coordinates of [src]. */
    fun detect(src: Bitmap, threshold: Float, deepScan: Boolean): List<Det> {
        val all = ArrayList(infer(src, threshold))
        if (deepScan) {
            val w = src.width
            val h = src.height
            val parts = if (h >= w) {
                listOf(Rect(0, 0, w, (h * 0.6f).toInt()), Rect(0, (h * 0.4f).toInt(), w, h))
            } else {
                listOf(Rect(0, 0, (w * 0.6f).toInt(), h), Rect((w * 0.4f).toInt(), 0, w, h))
            }
            for (r in parts) {
                val crop = Bitmap.createBitmap(src, r.left, r.top, r.width(), r.height())
                infer(crop, threshold).forEach {
                    all += it.copy(box = RectF(it.box).apply { offset(r.left.toFloat(), r.top.toFloat()) })
                }
                crop.recycle()
            }
        }
        return nms(all)
    }

    private fun infer(src: Bitmap, thr: Float): List<Det> {
        // Letterbox into a 320x320 black square, keeping aspect ratio.
        val scale = SIZE.toFloat() / max(src.width, src.height)
        val nw = (src.width * scale).roundToInt().coerceAtLeast(1)
        val nh = (src.height * scale).roundToInt().coerceAtLeast(1)
        val padX = (SIZE - nw) / 2
        val padY = (SIZE - nh) / 2
        val square = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        Canvas(square).apply {
            drawColor(Color.BLACK)
            drawBitmap(src, null, Rect(padX, padY, padX + nw, padY + nh), resizePaint)
        }

        val px = IntArray(SIZE * SIZE)
        square.getPixels(px, 0, SIZE, 0, 0, SIZE, SIZE)
        square.recycle()
        val plane = SIZE * SIZE
        val data = FloatArray(3 * plane)
        for (i in px.indices) { // RGB, planar, 0..1
            val p = px[i]
            data[i] = ((p shr 16) and 255) / 255f
            data[plane + i] = ((p shr 8) and 255) / 255f
            data[2 * plane + i] = (p and 255) / 255f
        }

        OnnxTensor.createTensor(env, FloatBuffer.wrap(data), longArrayOf(1, 3, SIZE.toLong(), SIZE.toLong())).use { t ->
            session.run(mapOf(inputName to t)).use { res ->
                @Suppress("UNCHECKED_CAST")
                val out = (res[0].value as Array<Array<FloatArray>>)[0]
                val chanFirst = out.size < out[0].size // [22][N] vs [N][22]
                val n = if (chanFirst) out[0].size else out.size
                fun v(c: Int, i: Int) = if (chanFirst) out[c][i] else out[i][c]

                val dets = ArrayList<Det>()
                for (i in 0 until n) {
                    var best = -1
                    var bs = thr
                    for (c in 0 until NUM_CLASSES) {
                        val s = v(4 + c, i)
                        if (s > bs) { bs = s; best = c }
                    }
                    if (best < 0) continue
                    val cx = v(0, i)
                    val cy = v(1, i)
                    val w = v(2, i)
                    val h = v(3, i)
                    val l = ((cx - w / 2) - padX) / scale
                    val tp = ((cy - h / 2) - padY) / scale
                    val r = ((cx + w / 2) - padX) / scale
                    val b = ((cy + h / 2) - padY) / scale
                    dets += Det(
                        best, bs,
                        RectF(
                            l.coerceIn(0f, src.width.toFloat()), tp.coerceIn(0f, src.height.toFloat()),
                            r.coerceIn(0f, src.width.toFloat()), b.coerceIn(0f, src.height.toFloat())
                        )
                    )
                }
                return nms(dets)
            }
        }
    }

    private fun nms(dets: List<Det>, iouThr: Float = 0.45f): List<Det> {
        val kept = ArrayList<Det>()
        for (d in dets.sortedByDescending { it.score }) {
            if (kept.none { it.cls == d.cls && iou(it.box, d.box) > iouThr }) kept += d
        }
        return kept
    }

    private fun iou(a: RectF, b: RectF): Float {
        val iw = min(a.right, b.right) - max(a.left, b.left)
        val ih = min(a.bottom, b.bottom) - max(a.top, b.top)
        if (iw <= 0 || ih <= 0) return 0f
        val inter = iw * ih
        return inter / (a.width() * a.height() + b.width() * b.height() - inter)
    }

    fun close() = session.close()
}
