package com.example.footonly

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

enum class Rule { OFF, CENSOR, ALLOW }
enum class Style { BOX, PIXELATE, BLUR }
enum class Mode { CENSOR_SELECTED, ONLY_SHOW_SELECTED }

fun ruleMap(censor: Collection<Int> = emptyList(), allow: Collection<Int> = emptyList()): Map<Int, Rule> =
    censor.associateWith { Rule.CENSOR } + allow.associateWith { Rule.ALLOW }

fun rulesToString(m: Map<Int, Rule>) =
    m.entries.filter { it.value != Rule.OFF }.joinToString(",") { "${it.key}:${it.value.name}" }

fun rulesFromString(s: String): Map<Int, Rule> =
    s.split(",").filter { it.contains(":") }.associate {
        val (k, v) = it.split(":")
        k.toInt() to Rule.valueOf(v)
    }

/** All user-tunable settings, shared by the UI and the accessibility service via SharedPreferences. */
data class FilterConfig(
    val paused: Boolean = false,
    val mode: Mode = Mode.CENSOR_SELECTED,
    val rules: Map<Int, Rule> = ruleMap(censor = NudeClasses.explicit),
    val style: Style = Style.PIXELATE,
    val intensity: Int = 28,          // pixel-block size (bigger = stronger)
    val threshold: Float = 0.30f,     // detection score needed (lower = catches more)
    val margin: Float = 0.15f,        // extra padding around each detected box
    val refreshMs: Int = 400,
    val deepScan: Boolean = false,    // also scan overlapping halves of the screen
    val ignoredApps: Set<String> = emptySet()
) {
    fun save(c: Context) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putBoolean("paused", paused)
            .putString("mode", mode.name)
            .putString("rules", rulesToString(rules))
            .putString("style", style.name)
            .putInt("intensity", intensity)
            .putFloat("threshold", threshold)
            .putFloat("margin", margin)
            .putInt("refreshMs", refreshMs)
            .putBoolean("deepScan", deepScan)
            .putStringSet("ignoredApps", ignoredApps.toSet())
            .apply()
    }

    companion object {
        const val FILE = "footonly"

        fun load(c: Context): FilterConfig {
            val p = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            val d = FilterConfig()
            return runCatching {
                FilterConfig(
                    paused = p.getBoolean("paused", d.paused),
                    mode = Mode.valueOf(p.getString("mode", d.mode.name)!!),
                    rules = p.getString("rules", null)?.let { rulesFromString(it) } ?: d.rules,
                    style = Style.valueOf(p.getString("style", d.style.name)!!),
                    intensity = p.getInt("intensity", d.intensity),
                    threshold = p.getFloat("threshold", d.threshold),
                    margin = p.getFloat("margin", d.margin),
                    refreshMs = p.getInt("refreshMs", d.refreshMs),
                    deepScan = p.getBoolean("deepScan", d.deepScan),
                    ignoredApps = p.getStringSet("ignoredApps", emptySet())!!.toSet()
                )
            }.getOrDefault(d)
        }
    }
}

data class Profile(val name: String, val mode: Mode, val rules: Map<Int, Rule>)

object Profiles {
    val builtins = listOf(
        Profile("Nudity only", Mode.CENSOR_SELECTED, ruleMap(censor = NudeClasses.explicit)),
        Profile("Nudity + faces", Mode.CENSOR_SELECTED, ruleMap(censor = NudeClasses.explicit + NudeClasses.faces)),
        Profile(
            "Feet only", Mode.ONLY_SHOW_SELECTED,
            ruleMap(censor = NudeClasses.explicit + NudeClasses.faces, allow = NudeClasses.feet)
        ),
        Profile("Strict", Mode.CENSOR_SELECTED, ruleMap(censor = NudeClasses.explicit + setOf(0, 5, 11, 13, 15, 16, 17)))
    )

    fun loadCustom(c: Context): List<Profile> = runCatching {
        val arr = JSONArray(c.getSharedPreferences(FilterConfig.FILE, Context.MODE_PRIVATE).getString("profiles", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Profile(o.getString("name"), Mode.valueOf(o.getString("mode")), rulesFromString(o.getString("rules")))
        }
    }.getOrDefault(emptyList())

    fun saveCustom(c: Context, list: List<Profile>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("name", it.name).put("mode", it.mode.name).put("rules", rulesToString(it.rules))
            )
        }
        c.getSharedPreferences(FilterConfig.FILE, Context.MODE_PRIVATE).edit().putString("profiles", arr.toString()).apply()
    }
}
