package com.example.footonly

/** NudeNet 320n output classes, in model order. */
object NudeClasses {
    val names = listOf(
        "Female genitalia (covered)", "Face (female)", "Buttocks (exposed)", "Female breast (exposed)",
        "Female genitalia (exposed)", "Male breast (exposed)", "Anus (exposed)", "Feet (exposed)",
        "Belly (covered)", "Feet (covered)", "Armpits (covered)", "Armpits (exposed)", "Face (male)",
        "Belly (exposed)", "Male genitalia (exposed)", "Anus (covered)", "Female breast (covered)",
        "Buttocks (covered)"
    )

    val faces = setOf(1, 12)
    val feet = setOf(7, 9)
    val explicit = setOf(2, 3, 4, 6, 14)

    /** Display order for the Parts tab. */
    val groups = listOf(
        "Faces" to listOf(1, 12),
        "Nudity (exposed)" to listOf(3, 4, 2, 6, 14),
        "Other exposed" to listOf(5, 13, 11),
        "Covered" to listOf(16, 0, 17, 15, 8, 10),
        "Feet" to listOf(7, 9)
    )
}
